from tkinter import *
# import tkinter as tk ## 클래스 접근을 다음과 같이 변경 => (tk.Tk(), tk.Button(), tk.Label())
import random
answer=random.randint(1,100)
def guessing():
    guess=int(guessField.get())

    if guess>answer:
        msg="높음!"
    elif guess<answer:
        msg="낮음!"
    else:
        msg="정답!"
    resultLabel["text"] = msg
    guessField.delete(0,5)

def reset():
    global answer
    answer=random.randint(1,100)
    resultLabel["text"]="다시 한번 하세요!"

window=Tk()
window.configure(bg="gray")
window.title("숫자를 맞춰보세요!")
window.geometry("500x80")
titleLabel=Label(window, text="환영합니다.!", bg="white")
titleLabel.pack()
guessField=Entry(window)
guessField.pack(side="left")
tryButton=Button(window, text="시도", fg="green", bg="white", command=guessing)
tryButton.pack(side="left")
resetButton=Button(window, text="초기화", bg="red", fg="white", command=reset)
resetButton.pack(side="left")
resultLabel=Label(window, text="1부터 100사이의 숫자를 입력하시오.",bg="white")
resultLabel.pack(side="left")
window.mainloop()


