# #list = []
# #list = [(x,y,z) for x in range(1,30) for y in range(1,30) for z in range(1,30) if x**2+y**2==z**2]
# #print(list)

# rows=3
# cols=5
# s=[]
# #s = [([0]*cols) for row in range(rows)]
# for row in range(rows):
#     s += [[row]*cols]
# print("s=", s)
# for r in range(rows):
#     for c in range(cols):
#         print(s[r][c], end=' ')
#     print()
# print(s[1])

# matrix=[[1,2,3],[4,5,6],[7,8,9]]
# trans=[  [row[i] for row in matrix] for i in range(len(matrix[0]))  ]
# print(trans)

# matrix=[[i for i in range(5)] for _ in range(6)]
# print(matrix)

# txt="I have a dream that one day every valley shall be exalted and every hill and mountain shall be made low"
# words=txt.split(" ")
# print(words)
# print(type(words))
# unique=set(words)
# print(len(unique), unique)

capitals={"kor":"seoul", "usa":"washington", "uk":"london"}

print(capitals.values())