# coding=<utf-8>
''' -*- conding: utf-8 -*- '''
# print("adfasdf한글")
# print("한글")

def f(x):
    return(x**2-x-1)

def bisection(a ,b, error):
    if f(a)*f(b) > 0:
        print("구간에서 근을 찾을 수 없습니다.")
    else:
        while (b-a)/2.0 >error :
            mid=(a+b)/2.0
            if f(mid) ==0 :
                return(mid)
            elif f(a)*f(mid)<0:
                b=mid
            else:
                a=mid

        return(mid)

ans=bisection(10, 2, 0.0001)

print("근:", ans)
