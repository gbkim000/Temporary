def printList(mylist):
    for row in range(len(mylist)):
        for col in range(len(mylist[0])):
            print(mylist[row][col], end=' ')
        print()

def init(mylist):
    for row in range(len(mylist)):
        for col in range(len(mylist[0])):
            print(row, col, end="\n")
            if ((row+col)%2) == 0:
                table[row][col]=1
            else:
                table[row][col]=0
table = []
#table = [[0]*10]*10
#printList(table)
#table=[]
for row in range(10):
    table += [[0]*10]
table = [[0]*10]*10
#printList(table)
#print(table)

init(table)
printList(table)

