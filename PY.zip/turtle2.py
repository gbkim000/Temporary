import random
import turtle
 
def turn_left():
        print("left확인중")
        t1.left(10)
        t1.forward(10)
def turn_left2():
        print("press확인중.")
        t1.left(10)
        t1.forward(10)
 
def turn_right():
        t1.right(10)
        t1.forward(10)
 
def square(length):
    for i in range(4):
        t1.forward(length)
        t1.left(90)
 
 
def drawit(x, y):       # 마우스의 x,y의 좌표로 가는 역할
    t1.penup()
    t1.goto(x, y)   # 마우스의 x,y의 좌표로 가는 역할
    t1.pendown()
    t1.begin_fill()
    t1.color("blue") #팬색깔과 채우기 색이 둘다 바뀐다.
    t1.pencolor("red")
    square(50)
    t1.end_fill()
 
t1 = turtle.Turtle()
 
 
turtle.bgcolor("green")     # 이거는 t1.bg컬러로 호출불가!
t1.color("pink")    #화살표를 분홍색으로 만듬
t1.pencolor("red")
t1.shape("turtle")  #화살표를 거북이 모양
t1.shapesize(5)     #화살표의 크기 조절 함수
t1.pensize(5)       #지나가는 길의 크기조절함
t1.fd(30)           #보는 방향으로 30이동
 
t1.width(2)           # 지나가는 길의 두께
t1.backward(300)     #뒤로30, 방향이 바뀌지 않음. 후진임
t1.penup()          #거북이 적용됨
t1.right(90)
t1.fd(30)           #보는 방향으로 30이동
t1.left(90)
t1.down()           #pendown과 같은듯 거북이도 잘 적용된다.
t1.fd(300)
t1.shapesize(1)     #화살표의 크기 조절 함수
t1.speed(111110)    #거북이의 속도,  최대가 0이다. 
 
t1.circle(30)
t1.begin_fill()     #다각형 색칠 적용시작
t1.fillcolor("black") # 다각형을채우는색깔 변경
                    #색만바꾸고 시작과끝을해야 적용
t1.fd(100)
for a in range(5):
    t1.fd(30)
    t1.left(360/5)
t1.end_fill()       # 다각형 색칠하기 끝
t1.up()
t1.fd(50)
t1.dot()
t1.fd(50)
t1.down()
 
t1.stamp()  #거북이 모양을 남김
t1.right(90)
t1.fd(40)
t1.write("Merry Christmas", font=("Arial", 24, "italic"))
                # 그위치에 글을 남김.
 
t2 = turtle.getscreen()  # 이거랑 이 밑에꺼랑 똑같다?
t2 = turtle.Screen()
 
t2.onscreenclick(drawit)  # 함수는 함수명만!  바로실행됨
t1.fd(30)
t2.onkey(turn_left, "Left") #screen에 onkey(함수명,"키보드")
t2.onkey(turn_right, "Right")# 누를때는 반응x 손땔때 반응 ok
t2.onkeypress(turn_left2, "Left")  # 누르고 있을때 함수 
t2.onkeypress(turn_right, "Right")
t3 = turtle.Turtle()
t3.goto(-300,-200)
def gogo():
        print("")
        print("ontimer 수행중")
        t3.fd(30)        # 진행상태를보아서 ontimer후
        t2.ontimer(gogo, 1000) # 1초후에 함수를실행
        print("ontimer 끝")      # 1초 대기상태가아닌
t2.ontimer(gogo, 1000)  # 1초 후로 되서 끝이 바로출력.
 
t1.penup();
t1.goto(-300, 250)
t1.speed(0)
t1.pendown();
 
  
t2.listen()# listen을 해야지 키를 눌렀을때 듣고 반응을함.
t2.mainloop()   # 안해도 돌아가는데 왜하는지 잘 모르겠음.